package com.fannie.client;

import java.sql.SQLException;
import java.util.Scanner;

import com.fannie.bean.Account;
import com.fannie.connection.GetConnection;
import com.fannie.dao.AccountDAO;
import com.fannie.interfaces.IAccountDAO;


public class AccountClient {
	public static void main(String[] args) {
		IAccountDAO dao = new AccountDAO();

		try {

			System.out.println("Displaying All records before Update");
			for(Account temp: dao.getAllAccs()){
				System.out.println(temp);
			}


			for(Account temp: dao.getOnebyOneAccs()){				
				System.out.println(temp);
			}

			System.out.println("Done Displaying All records after Update");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}