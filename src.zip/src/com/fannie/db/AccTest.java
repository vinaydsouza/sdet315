package com.fannie.db;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.fannie.bean.Account;
import com.fannie.client.AccountClient;
import com.fannie.dao.AccountDAO;

import org.junit.Test;

public class AccTest { 
	
	static AccountDAO adb = null;
	static Account acc = null;
	
	@BeforeClass	
	public static void empObjInit(){
		System.out.println("Before Class called >>>>");
		adb = new AccountDAO();
		acc = new Account();
	}
	
	@Before
	public void beforeAllMethods(){
		System.out.println("hi i'm from Before >>>>");
	}	
		
	//Test Get All Accs	
	
	@Test (timeout=100) 
	public void getAllAccsPassTest() {		
		//all your test goes here
		AccountDAO adb = new AccountDAO();	
		Account acc = new Account();	
		assertEquals("Testing to Check Account Pass", true, adb.getAllAccs());
	}
	
	@Test (timeout=100)
	public void getAllAccsFailTest() {		
		//all your test goes here
		AccountDAO adb = new AccountDAO();	
		Account acc = new Account();	
		assertNotEquals("Testing to Check Account Pass", true, adb.getAllAccs());
	}
	
	@After
	public void afterAllMethods(){
		System.out.println("hi i'm from After >>>>");
	}
}