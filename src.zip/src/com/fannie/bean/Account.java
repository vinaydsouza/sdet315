package com.fannie.bean;

public class Account {
	private int accId;
	private int accNo;
	private float accBal;
	private float avgBal;
	
	@Override
	public String toString() {
		return "Account [accId=" + accId + ", accNo=" + accNo + ", accBal=" + accBal + ", avgBal=" + avgBal + "]";
	}	
	
	public Account() {
		}

	public Account(int accId, int accNo, float accBal, float avbBal) {
		super();
		this.accId = accId;
		this.accNo = accNo;
		this.accBal = accBal;
		this.avgBal = avbBal;
	}
	
	public Account(int accNo, float accBal, float avbBal) {
		super();
		this.accNo = accNo;
		this.accBal = accBal;
		this.avgBal = avbBal;
	}
	
	public int getAccId() {
		return accId;
	}

	public void setAccId(int accId) {
		this.accId = accId;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public float getAccBal() {
		return accBal;
	}

	public void setAccBal(float accBal) {
		this.accBal = accBal;
	}

	public float getAvgBal() {
		return avgBal;
	}

	public void setAvgBal(float avgBal) {
		this.avgBal = avgBal;
	}
	
	
}