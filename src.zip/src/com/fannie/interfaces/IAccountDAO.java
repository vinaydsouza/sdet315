package com.fannie.interfaces;

import java.util.List;

import com.fannie.bean.Account;

public interface IAccountDAO {
	public boolean insertAccount(Account acc);
	public List<Account> getAllAccs();
	public List<Account> getOnebyOneAccs();
	public Account getAcc(int accId);
	public boolean updateAcc(int accId, float newBal);
	public boolean deleteAcc(int accId);
}
