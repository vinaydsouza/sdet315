package com.fannie.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.fannie.bean.Account;
import com.fannie.connection.GetConnection;
import com.fannie.interfaces.IAccountDAO;

import java.util.Scanner;
public class AccountDAO implements IAccountDAO {

	@Override
	public List<Account> getAllAccs() {		
		String sql ="select * from account";
		List<Account> accs = new ArrayList<Account>();
		GetConnection gc = new GetConnection();
		try {
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			
			gc.rs = gc.ps.executeQuery();

			for(;gc.rs.next();){
				Account temp = new Account();
				temp.setAccId(gc.rs.getInt(1));
				temp.setAccNo(gc.rs.getInt(2));
				temp.setAccBal(gc.rs.getFloat(3));	
				temp.setAvgBal(gc.rs.getFloat(4));
				
				accs.add(temp) ; 
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return accs;
	}		
		@Override
		public List<Account> getOnebyOneAccs() {			
			String sql ="select * from account";
			List<Account> accs = new ArrayList<Account>();
			GetConnection gc = new GetConnection();
			try {
				gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
				
				gc.rs = gc.ps.executeQuery();
				
			
				for(;gc.rs.next();){
					Account temp = new Account();
					temp.setAccId(gc.rs.getInt(1));
					temp.setAccNo(gc.rs.getInt(2));
					temp.setAccBal(gc.rs.getFloat(3));
					
					System.out.println("Enter the % value to be updated for AvgBal: ");
					Scanner s = new Scanner(System.in);
					String str = s.nextLine();
					int perCount = Integer.parseInt(str);
					
					System.out.println ("The current Avg Bal for this record is: " +gc.rs.getFloat(4));
					
					int actId = gc.rs.getInt(1);
					float AvgBal = (gc.rs.getFloat(4) * perCount)/100; // Update the AvgBal based on %
					
					System.out.println ("The updated Avg Bal for this record now is: " +AvgBal);
					
					temp.setAvgBal(AvgBal);  //Display the Updated Avg Balance
					updateAcc(actId, AvgBal); //Update the Avg Balance in DB
					
					accs.add(temp) ; 

				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return accs;
		}	
		
	@Override
	public Account getAcc(int accId) {
		String sql ="select * from account where account_ID =?";
		
		GetConnection gc = new GetConnection();
		try {
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			gc.ps.setInt(1, accId);

			gc.rs = gc.ps.executeQuery();
			
	
			if(gc.rs.next()){
				Account temp = new Account();
				temp.setAccId(gc.rs.getInt(1));
				temp.setAccNo(gc.rs.getInt(2));
				temp.setAccBal(gc.rs.getFloat(3));
				temp.setAvgBal(gc.rs.getFloat(4));
				
				return temp;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return null;
	}

	@Override
	public boolean updateAcc(int accId, float newBal) {
		String sql ="update Account set average_balance = ? where account_ID =?";
		
		
		GetConnection gc = new GetConnection();
		try {
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			gc.ps.setFloat(1, newBal);
			gc.ps.setInt(2, accId);

			
			return gc.ps.executeUpdate()>0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
 	}

	@Override
	public boolean insertAccount(Account acc) {
		try {
		String sql ="insert into account(Account_ID,Account_No, Balance,Average_Balance) values(?,?,?,?)";
			
			GetConnection gc = new GetConnection();
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			gc.ps.setInt(1, acc.getAccId());
			gc.ps.setInt(2, acc.getAccNo());
			gc.ps.setFloat(3, acc.getAccBal());
			gc.ps.setFloat(4, acc.getAvgBal());
			
			return gc.ps.executeUpdate() >0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		return false;
	}	
	
	@Override
	public boolean deleteAcc(int accId) {
		String sql ="delete from Account where accID=?";
		
		GetConnection gc = new GetConnection();
		try {
//			GetConnection.mysqlCon().setAutoCommit(false);
			gc.ps = GetConnection.mysqlCon().prepareStatement(sql);
			gc.ps.setInt(1, accId);
			
			return gc.ps.executeUpdate()>0;
			
		} catch (SQLException e) {
			try {
				GetConnection.mysqlCon().rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally{
			try {
				gc.ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		
		return false;
	}

}
