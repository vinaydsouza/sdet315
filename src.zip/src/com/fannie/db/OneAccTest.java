package com.fannie.db;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.fannie.bean.Account;
import com.fannie.client.AccountClient;
import com.fannie.dao.AccountDAO;

import org.junit.Test;

public class OneAccTest {
	
	static AccountDAO adb = null;
	static Account acc = null;

	//Test Get Accs One by One
	
	@Test (timeout=100)
	public void getOnebyOneAccsPassTest() {		
		//all your test goes here
		AccountDAO adb = new AccountDAO();	
		Account acc = new Account();	
		assertEquals("Testing to Check Account Pass", true, adb.getOnebyOneAccs());
	}
		
	@Test (timeout=100)
	public void getOnebyOneAccsFailTest() {		
		//all your test goes here
		AccountDAO adb = new AccountDAO();	
		Account acc = new Account();	
		assertNotEquals("Testing to Check Account Pass", true, adb.getOnebyOneAccs());
	}

}
