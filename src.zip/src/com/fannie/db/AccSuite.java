package com.fannie.db;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AccTest.class, OneAccTest.class, UpdAccTest.class, InsAccTest.class })

public class AccSuite {

}
