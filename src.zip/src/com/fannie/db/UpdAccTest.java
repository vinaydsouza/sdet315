package com.fannie.db;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.fannie.bean.Account;
import com.fannie.client.AccountClient;
import com.fannie.dao.AccountDAO;

import org.junit.Test;

public class UpdAccTest {
	
	//Test Update Accs 
	
	@Test (timeout=100)
	public void updAccsPassTest() {		
		//all your test goes here
		AccountDAO adb = new AccountDAO();	
		Account acc = new Account();	
		assertEquals("Testing to Check Account Pass", true, adb.updateAcc(1,1));
	}
	
	
	@Test (timeout=100)
	public void updAccsFailTest() {		
		//all your test goes here
		AccountDAO adb = new AccountDAO();	
		Account acc = new Account();	
		assertNotEquals("Testing to Check Account Pass", true, adb.updateAcc(1,1));
	}
}
